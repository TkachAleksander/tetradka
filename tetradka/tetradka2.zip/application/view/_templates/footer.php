	<div class="footer">
      <p class="text-center">Copyright © 2016. Интернет-магазин канцтоваров "Tetradka"</p>
  </div>

</body>
</html>