<script type="text/javascript"> 
	deleteCookie();
</script>

<div class="container floor-container">
    <div class="col-md-12">
        <div class="row">
            <div class="products col-lg-offset-1 col-lg-10 floor-order text-center">

            		<div class="row">
						<img class="img-responsive successful" src="<?php echo URL;?>img/successful.png">
						<span class="MarckScript text-index">Ваш заказ принят.</span>
					</div>

					<div class="row">
				 		<p class="MarckScript text-index">В ближайшее время мы свяжемся с вами для подтверждения заказа.</p>
						<a href="<?php echo URL; ?>" class="btn btn-success btn-sm"><b>Продолжить покупки</b></a>
					</div>

            </div>
        </div>
    </div>
</div>
