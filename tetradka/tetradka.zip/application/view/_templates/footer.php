	<div class="footer">
      <p class="text-center">Copyright © 2016. Интернет-магазин канцтоваров "Tetradka"</p>
  </div>

  <script type="text/javascript" src="<?php echo URL; ?>js/google.js"></script>
</body>
</html>